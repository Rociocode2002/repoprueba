/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tads.listaGeneric;

import java.util.HashSet;
import tads.listaGeneric.Nodo;


/**
 *
 * @author Admin
 */
public class ListaS<T extends Comparable<? super T>> implements IListaS<T>
 {

    private Nodo <T> inicio;
    
    
    public ListaS() {
        inicio = null;
    }
    
    
    private Nodo getInicio(){
        return inicio;
    }
    private void setInicio(Nodo inicio) {
        this.inicio = inicio;
    }

    
    
    @Override
    public boolean esVacia() {
        return inicio == null;
    }

    @Override
    public void agregarInicio(T dato) {
        Nodo nuevo = new Nodo(dato);
        nuevo.setDato(dato);
        nuevo.setSiguiente(inicio); //
        inicio = nuevo;
    }

    @Override
    public void agregarFinal(T dato) {
       Nodo nuevo = new Nodo(dato);
       if(inicio == null){
           inicio = nuevo;    
       }else{
       
       Nodo actual = inicio;
       
       while(actual.getSiguiente() != null){
           
           actual = actual.getSiguiente();
           
       }
       actual.setSiguiente(nuevo);
           
       
       }
    }
      @Override
    public int cantidadElementos() {
    if (esVacia()) { 
        return 0;
    }
    
    int contador = 0;
    Nodo<T> aux = inicio;
    
    while (aux != null) {
        contador++;
        aux = aux.getSiguiente();
    }
    
    return contador;
}

    @Override
    public void borrarInicio() {
        if(!esVacia()){
            inicio = inicio.getSiguiente();
        }
    }
    

    @Override
    public void borrarFin() {
    //Lista vacia   
    if (inicio == null) {
        return;
    }

    //Si solo hay un dato
    if (inicio.getSiguiente() == null) {
        inicio = null;
        return;
    }

    Nodo<T> actual = inicio;
    while (actual.getSiguiente().getSiguiente() != null) {
        actual = actual.getSiguiente();
    }

    actual.setSiguiente(null);
    }
    
    
        
    //@Override
    public void borrarElemento (T dato){
    if (inicio != null) {

            if (inicio.getDato().equals(dato)) {
                inicio = inicio.getSiguiente();
            } else {
                Nodo actual = inicio;
                 while (actual.getSiguiente() != null && !actual.getSiguiente().getDato().equals(dato)) {
                actual = actual.getSiguiente();
                }
                if (actual.getSiguiente() != null) {
                    Nodo<T> aBorrar = actual.getSiguiente();
                    actual.setSiguiente(aBorrar.getSiguiente());
                    aBorrar.setSiguiente(null);

                }
            }
        }
   }
    
    
    @Override
    public void vaciar() {
        inicio = null;
    }

    @Override
    public String mostrar() {
      
        Nodo<T> mostrar = inicio;
        String res = "";
        while (mostrar != null) {
            res += mostrar.getDato() + "#";
            mostrar = mostrar.getSiguiente();
        }
        
        return res;
        

    }

    @Override
    
    // el primer elemento es la posicion 0
    public T obtenerElemento(int indice) {

        Nodo <T> aux = inicio;

        int actual = 0;
        
        while (aux != null) {
            if(actual == indice){
                return aux.getDato();
            } else {
                aux = aux.getSiguiente();
                actual++;
            }
        }
        throw new IndexOutOfBoundsException();
        
    }
    
    //@Override
    public boolean existeElemento(T elemento){
    
        Nodo aux = inicio;
        boolean existe = false;
        
        while(aux != null && !existe){
            if(aux.getDato().equals(elemento)){
                existe = true;
            }
            aux = aux.getSiguiente();
        }
        return existe;
        
    
    
    }
    
//    public ListaS invertir(){
//        ListaS resultado = new ListaS();
//        Nodo aux= inicio; 
//        while (aux!=null){
//            resultado.agregarInicio(aux.getDato());
//            aux = aux.getSiguiente();
//        }
//        
//        return resultado;
//    }
    
    
    
    // PRE: La lista está ordenada en forma ascendente
    // POST: Se genera un lista ordenada con el nuevo elemento incorporado
    
    public void insertarOrdenado(T dato) {
    // Caso lista vacía
    if (esVacia()) {
        agregarInicio(dato);
    } else {
        // Lista con un solo elemento
        if (inicio.getSiguiente() == null) {
            if (dato.compareTo(inicio.getDato()) > 0) {
                agregarFinal(dato);
            } else {
                agregarInicio(dato);
            }
        } else {
            // El dato es menor que el primero
            if (dato.compareTo(inicio.getDato()) < 0) {
                agregarInicio(dato);
            } else {
                // Caso general: insertar en el medio o final
                Nodo<T> aux = inicio;
                Nodo<T> insertar = new Nodo<>(dato);
                insertar.setDato(dato);

                // Avanzar hasta encontrar la posición correcta
                while (aux.getSiguiente() != null && aux.getSiguiente().getDato().compareTo(dato) <= 0) {
                    aux = aux.getSiguiente();
                }

                insertar.setSiguiente(aux.getSiguiente());
                aux.setSiguiente(insertar);
            }
        }
    }
    }
    
  
    
    
}
