/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;
import java.time.LocalDate;
import tads.listaGeneric.ListaS;

/**
 *
 * @author rocio
 */
public class Evento  implements Comparable<Evento> {
    
    private String codigoEvento;
    private String Descripcion ;
    private int aforoNecesario;
    private LocalDate Fecha ;

    public String getCodigoEvento() {
        return codigoEvento;
    }

    public void setCodigoEvento(String codigoEvento) {
        this.codigoEvento = codigoEvento;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public int getAforoNecesario() {
        return aforoNecesario;
    }

    public void setAforoNecesario(int aforoNecesario) {
        this.aforoNecesario = aforoNecesario;
    }

    public LocalDate getFecha() {
        return Fecha;
    }

    public void setFecha(LocalDate Fecha) {
        this.Fecha = Fecha;
    }
    
    @Override
    public int compareTo(Evento otro) {
        return this.codigoEvento.compareTo(otro.codigoEvento);
    }
    
     @Override
    public String toString() {
    return " Codigo: " + codigoEvento + ", Descripcion: " + Descripcion + "Fecha" + Fecha ;
    }
    
    
}
