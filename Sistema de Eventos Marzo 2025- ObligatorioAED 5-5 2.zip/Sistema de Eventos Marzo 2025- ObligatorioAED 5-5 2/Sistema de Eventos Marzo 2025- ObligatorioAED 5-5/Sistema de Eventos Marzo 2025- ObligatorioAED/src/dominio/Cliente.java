/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;
import tads.listaGeneric.ListaS; 

/**
 *
 * @author rocio
 */
public class Cliente implements Comparable<Cliente>{ 
    
  private  String Cedula;
  private String Nombre;

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String Cedula) {
        this.Cedula = Cedula;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
     @Override 
     public int compareTo(Cliente obj) {
     Cliente otro = (Cliente) obj; 
     return this.Cedula.compareTo(otro.Cedula);

    }
     
     @Override//VER
    public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;

    Cliente otro = (Cliente) obj;
    return this.Cedula.equals(otro.Cedula);
}
      @Override
    public String toString() {
    return " Cedula: " + Cedula + ", Nombre: " + Nombre;
    }
      
}
