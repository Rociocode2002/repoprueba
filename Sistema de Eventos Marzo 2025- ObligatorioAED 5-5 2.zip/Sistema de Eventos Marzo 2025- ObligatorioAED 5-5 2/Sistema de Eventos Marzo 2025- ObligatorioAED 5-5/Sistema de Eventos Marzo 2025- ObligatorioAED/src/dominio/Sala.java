/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;
import tads.listaGeneric.ListaS;
import dominio.Evento;


/**
 *
 * @author rocio
 */
public class Sala implements Comparable<Sala> {

    private String nombre;
    private int capacidad;
    
    // public ListaS<Evento> = new ListaS();

        private ListaS<Evento> eventos;
    
       
    public Sala(){
        eventos = new ListaS<>();
   }

  public ListaS<Evento> getEventos() {
        return eventos;
    }

    public void setEventos(ListaS<Evento> eventos) {
        this.eventos = eventos;
    }
   

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Sala)) {
            return false;

        }
        if (obj == null) {

            return false;

        }
        return this.nombre == ((Sala) obj).getNombre();

    }
    
     @Override
        public int compareTo(Sala otra) {
        return this.nombre.compareTo(otra.nombre);
        
        
    }
    
    @Override
    public String toString() {
    return " Nombre: " + nombre + ", Capacidad: " + capacidad;
}

}
