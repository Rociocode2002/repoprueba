package sistemaAutogestion;

import tads.listaGeneric.ListaS;
import tads.listaGeneric.IListaS;
import tads.listaGeneric.Nodo;
import java.time.LocalDate;
//import dominio.Cliente;
import dominio.Cliente;
import dominio.Evento;
import dominio.Sala;
import java.util.HashSet;
import java.util.Set;
import sistemaAutogestion.Retorno;


public class Sistema implements IObligatorio {

    private ListaS<Cliente> Clientes;
    private ListaS<Evento> Eventos;
    private ListaS<Sala> Salas;

    public Sistema() {
        crearSistemaDeGestion();
    }

    @Override
    public Retorno crearSistemaDeGestion() {
        //1.1
        Clientes = new ListaS<>();
        Eventos = new ListaS<>();
        Salas = new ListaS<>(); 

        return (Retorno.ok());
    }

    //////////1.2 RegistrarSala////////////
@Override
    public Retorno registrarSala(String nombre, int capacidad) {

        if (capacidad <= 0) {

            return (Retorno.error2());// si la capacidad es menor o igual a 0
        }
        Sala sBuscar = new Sala();
        sBuscar.setNombre(nombre);

        boolean SalaExiste = Salas.existeElemento(sBuscar);

        if (SalaExiste == true) {

            return (Retorno.error1());// ya existe una sala con ese nombre
        }

        // Agregar la sala
        Sala nuevaSala = new Sala();
        nuevaSala.setNombre(nombre);
        nuevaSala.setCapacidad(capacidad);
        Salas.agregarInicio(nuevaSala);

        return (Retorno.ok());
    }

    ///////////////1.3 eliminar Sala/////////
    @Override
    public Retorno eliminarSala(String nombre) {

        Sala buscarSala = new Sala();

        buscarSala.setNombre(nombre);
        boolean ExisteSala = Salas.existeElemento(buscarSala);
        if (ExisteSala == false) {
            return (Retorno.error1());// no existe una sala con ese nombre
        }
        
        Salas.borrarElemento(buscarSala);
       
        return Retorno.ok(); //Se pudo eliminar la sala 
    }
        
       

    ///1.4 Registrar evento///////////////////////////////////////
    @Override
public Retorno registrarEvento(String codigo, String descripcion, int aforoNecesario, LocalDate fecha) {

        if (aforoNecesario <= 0) {
             System.out.print("error 2" );
            return (Retorno.error2());// aforo no puede ser menor o igual a 0
        }

        Evento eventoBuscar = new Evento();
        eventoBuscar.setCodigoEvento(codigo);
        boolean EventoExtiste = Eventos.existeElemento(eventoBuscar);

        if (EventoExtiste == true) {
             System.out.print("error 1" );
            return (Retorno.error1());// ya existe un evento con ese codigo
            
        }

        for (int i = 0; i < Salas.cantidadElementos(); i++) {
            Sala sala = Salas.obtenerElemento(i);

            if (sala.getCapacidad() >= aforoNecesario) {

                boolean fechaOcupada = false;
                for (int j = 0; j < sala.getEventos().cantidadElementos(); j++) {
                    Evento ev = sala.getEventos().obtenerElemento(j);
                    if (ev.getFecha().equals(fecha)) {
                        fechaOcupada = true;
                        break;
                    }
                }

                if (fechaOcupada == false) {
                    
                Evento nuevoEvento = new Evento();
                nuevoEvento.setCodigoEvento(codigo);
                nuevoEvento.setDescripcion(descripcion);
                nuevoEvento.setAforoNecesario(aforoNecesario);
                nuevoEvento.setFecha(fecha);
                
                // Agregar evento a la sala y a la lista general
                sala.getEventos().agregarFinal(nuevoEvento);
                Eventos.agregarFinal(nuevoEvento);
                
                System.out.println("Evento registrado: " + nuevoEvento.toString());
                
                return Retorno.ok();
                }
                
                
            }

            
          

        }
         System.out.print("error 3" );
return Retorno.error3();

    }

    ///1.5 Registrar cliente//////////////////////

    @Override
    public Retorno registrarCliente(String cedula, String nombre) {
        //1.5 registrar Cliente
        if (cedula.length() != 8) {

            return (Retorno.error1());// cedula invalida

        }
        Cliente buscarCliente = new Cliente();
        buscarCliente.setCedula(cedula);
        boolean existeCliente = Clientes.existeElemento(buscarCliente);

        if (existeCliente == true) {
            return (Retorno.error2()); //Cliente ya registrado 

        }

       
        buscarCliente.setNombre(nombre);
        Clientes.insertarOrdenado(buscarCliente);
      
        return Retorno.ok();
    }

    @Override
    public Retorno comprarEntrada(String cedula, String codigoEvento) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno eliminarEvento(String codigo) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno devolverEntrada(String cedula, String codigoEvento) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno calificarEvento(String cedula, String codigoEvento, int puntaje, String comentario) {
        return Retorno.noImplementada();
    }

    ///////2.1 Listar salas///////////
    @Override
    public Retorno listarSalas() {
       
        String listarSala =Salas.mostrar();

        Retorno ret = Retorno.ok();
        ret.valorString =listarSala;
    //    System.out.print(ret); //BORRAR
        return ret;
        
    }

        
        
  

    //2.2 Listar eventos//////////////////
    @Override
    public Retorno listarEventos() {
        
         String listarEventos = Eventos.mostrar();
         Retorno ret = Retorno.ok();
         ret.valorString = listarEventos;
      System.out.print(listarEventos.toString()); //BORRAR
         return ret;
    }

    //2.3 Listar clientes/////////////////////
    @Override
   public Retorno listarClientes() {
        
        String listarCliente = Clientes.mostrar();

        Retorno ret = Retorno.ok();
        ret.valorString =listarCliente;
        System.out.print(listarCliente); //BORRAR
        return ret;
      
       
    }

    /// 2.4 Sala optima //////////////////
    @Override
   public Retorno esSalaOptima(String vistaSala[][]) {
    if (vistaSala == null || vistaSala.length == 0 || vistaSala[0].length == 0) {
       // return Retorno.ERROR;
    }

    int columnasCumplen = 0;
    int columnas = vistaSala[0].length;

    for (int col = 0; col < columnas; col++) {
        int ocupadosConsecutivos = 0;
        int maxOcupadosConsecutivos = 0;
        int libres = 0;
        boolean encontreLimite = false;

        for (int fila = 0; fila < vistaSala.length && !encontreLimite; fila++) {
            String asiento = vistaSala[fila][col];

            if (asiento.equals("O")) {
                ocupadosConsecutivos++;
                if (ocupadosConsecutivos > maxOcupadosConsecutivos) {
                    maxOcupadosConsecutivos = ocupadosConsecutivos;
                }
            } else if (asiento.equals("X")) {
                libres++;
                ocupadosConsecutivos = 0;
            } else if (asiento.equals("#")) {
                ocupadosConsecutivos = 0;
                encontreLimite = true;  // Salimos del bucle si encontramos límite
            }
        }

        if (maxOcupadosConsecutivos > libres) {
            columnasCumplen++;
        }
    }

    if (columnasCumplen >= 2) {
        
        return Retorno.ok();
    } 
    
            return Retorno.noImplementada();

}

    @Override
    public Retorno listarClientesDeEvento(String código, int n) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno listarEsperaEvento() {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno deshacerUtimasCompras(int n) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno eventoMejorPuntuado() {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno comprasDeCliente(String cedula) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno comprasXDia(int mes) {
        return Retorno.noImplementada();
    }

}
