/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package sistemaAutogestion;
import sistemaAutogestion.Sistema;
import sistemaAutogestion.Retorno;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.time.LocalDate;


/**
 *
 * @author pesce
 */
public class IObligatorioTest {

   // private Sistema miSistema;
   private sistemaAutogestion.Sistema miSistema;

    public IObligatorioTest() {
    }

    @Before
    public void setUp() {
        
        miSistema = new Sistema();
        miSistema.crearSistemaDeGestion();   
        
        
    }

    @Test
    public void testCrearSistemaDeGestion() {
         Retorno ret =miSistema.crearSistemaDeGestion();
         assertEquals(Retorno.ok().resultado, ret.resultado);
    }
     //////__________________________________________________________________
    @Test
    public void testRegistrarSalaOK() {
        ///Carga de datos 
        Retorno ret1 = miSistema.registrarSala("sala1", 20);
        assertEquals(Retorno.ok().resultado, ret1.resultado);
        Retorno ret2 = miSistema.registrarSala("sala2", 30);
        assertEquals(Retorno.ok().resultado, ret2.resultado);
        Retorno ret3 = miSistema.registrarSala("sala3", 30);
        assertEquals(Retorno.ok().resultado, ret3.resultado);
    }
    @Test
     public void testRegistrarSalaERROR1() {
        ///Carga de datos 
        Retorno ret1 = miSistema.registrarSala("sala1", 20);
        assertEquals(Retorno.ok().resultado, ret1.resultado);
        Retorno ret2 = miSistema.registrarSala("sala1", 30);
        assertEquals(Retorno.error1().resultado, ret2.resultado);
    }
         @Test
     public void testRegistrarSalaERROR2() {
        ///Carga de datos 
        Retorno ret1 = miSistema.registrarSala("sala1", 20);
        assertEquals(Retorno.ok().resultado, ret1.resultado);
        Retorno ret2 = miSistema.registrarSala("sala2", 0);
        assertEquals(Retorno.error2().resultado, ret2.resultado);
    }
    //////__________________________________________________________________
    @Test
    public void testEliminarSalaOK() {
        //Carga de Datos
        Retorno ret1 = miSistema.registrarSala("sala1", 20);
        assertEquals(Retorno.ok().resultado, ret1.resultado);
        Retorno ret2 = miSistema.registrarSala("sala2", 30);
        assertEquals(Retorno.ok().resultado, ret2.resultado);
        Retorno ret3 = miSistema.registrarSala("sala3", 30);
        assertEquals(Retorno.ok().resultado, ret3.resultado);
        ///Prueba
        Retorno ret = miSistema.eliminarSala("sala2");
        assertEquals(Retorno.ok().resultado, ret.resultado);
        }
 
    @Test
    public void testEliminarSalaERROR1() {
        //Carga de Datos
        Retorno ret1 = miSistema.registrarSala("sala1", 20);
        assertEquals(Retorno.ok().resultado, ret1.resultado);
        Retorno ret2 = miSistema.registrarSala("sala2", 30);
        assertEquals(Retorno.ok().resultado, ret2.resultado);
        Retorno ret3 = miSistema.registrarSala("sala3", 30);
        assertEquals(Retorno.ok().resultado, ret3.resultado);
        ///Prueba
        Retorno ret = miSistema.eliminarSala("sala5");
        assertEquals(Retorno.error1().resultado, ret.resultado);
        }
    //////__________________________________________________________________
    @Test
    public void testRegistrarEvento() {
            Retorno ret1 = miSistema.registrarSala("sala1", 20);
        Retorno ret2 = miSistema.registrarSala("sala2", 30);
         Retorno ret = miSistema.registrarEvento("1344","evento de la luna",30,LocalDate.of(2028,3,3));
         
        assertEquals(Retorno.ok().resultado, ret.resultado);
    }
    //////__________________________________________________________________
    @Test
    public void testRegistrarClienteOK() {
       Retorno ret1 =  miSistema.registrarCliente("12345678","arturo");
       assertEquals(Retorno.ok().resultado, ret1.resultado);
       Retorno ret2 =  miSistema.registrarCliente("52345679","roberto");
       assertEquals(Retorno.ok().resultado, ret2.resultado);
       Retorno ret3 =  miSistema.registrarCliente("32345678","alf");
       assertEquals(Retorno.ok().resultado, ret3.resultado);

    }
     @Test
    public void testRegistrarClienteERROR1() {
       Retorno ret1 =  miSistema.registrarCliente("12345678","arturo");
       assertEquals(Retorno.ok().resultado, ret1.resultado);
       Retorno ret2 =  miSistema.registrarCliente("52345679","roberto");
       assertEquals(Retorno.ok().resultado, ret2.resultado);
       Retorno ret3 =  miSistema.registrarCliente("323456789","alf");
       assertEquals(Retorno.error1().resultado, ret3.resultado);

    }
    @Test
    public void testRegistrarClienteERROR2() {
       Retorno ret1 =  miSistema.registrarCliente("12345678","arturo");
       assertEquals(Retorno.ok().resultado, ret1.resultado);
       Retorno ret2 =  miSistema.registrarCliente("52345679","roberto");
       assertEquals(Retorno.ok().resultado, ret2.resultado);
       Retorno ret3 =  miSistema.registrarCliente("12345678","alf");
       assertEquals(Retorno.error2().resultado, ret3.resultado);

    }
     //////__________________________________________________________________

    @Test
    public void testListarSalas() {
        //Cargar datos 
        Retorno ret1 = miSistema.registrarSala("sala1", 20);
        assertEquals(Retorno.ok().resultado, ret1.resultado);
        Retorno ret2 = miSistema.registrarSala("sala2", 30);
        assertEquals(Retorno.ok().resultado, ret2.resultado);
        Retorno ret3 = miSistema.registrarSala("sala3", 30);
        assertEquals(Retorno.ok().resultado, ret3.resultado);
        //PRUEBA
        Retorno ret = miSistema.listarSalas();
        
        
       System.out.print(ret.valorString);

        
       assertEquals(Retorno.ok().resultado, ret.resultado);
       
       //String resultadoListado= " Nombre: sala3, Capacidad: 30# Nombre: sala2, Capacidad: 30# Nombre: sala1, Capacidad: 20#------------- ---------------- ---------------";
      // assertEquals(resultadoListado, ret.valorString);         
    }
//////__________________________________________________________________
    @Test
    public void testListarEventos() {
   Retorno ret1 = miSistema.registrarSala("sala1", 20);
        Retorno ret2 = miSistema.registrarSala("sala2", 30);
         Retorno ret = miSistema.registrarEvento("1344","evento de la luna",30,LocalDate.of(2028,3,3));
         
        assertEquals(Retorno.ok().resultado, ret.resultado);
    }
//////__________________________________________________________________
    @Test
    public void testListarClientes() {
        //carga de datos 
       Retorno ret1 =  miSistema.registrarCliente("12345678","arturo");
        assertEquals(Retorno.ok().resultado, ret1.resultado);
       Retorno ret2 =  miSistema.registrarCliente("52345679","roberto");
        assertEquals(Retorno.ok().resultado, ret2.resultado);
       Retorno ret3 =  miSistema.registrarCliente("62345670","alf");
        assertEquals(Retorno.ok().resultado, ret3.resultado);
      //Prueba 
       Retorno ret = miSistema.listarClientes();
       assertEquals(Retorno.ok().resultado, ret.resultado);
       //String resultadoListado=
       //assertEquals(resultadoListado, ret.valorString); 
    }
//////__________________________________________________________________
    @Test
    public void testEsSalaOptima() {
        //Completar para primera entrega
    }
 


}
